﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Biblioteka_projekt_2._0;

namespace Biblioteka_Gui_2._0
{
    /// <summary>
    /// Logika interakcji dla klasy ZwrocWindowxaml.xaml
    /// </summary>
    public partial class ZwrocWindowxaml : Window
    {
        private Biblioteka biblioteka;
        public ZwrocWindowxaml(Biblioteka biblioteka)
        {
            InitializeComponent();
            this.biblioteka = biblioteka;
            btnZwroc.Click += BtnZwroc_Click;
        }
        private void BtnZwroc_Click(object sender, RoutedEventArgs e)
        {

            string idKsiazkiZ = IDzwrotu.Text;
            string peselUzytkownikaZ = PeselZwrotu.Text;

            Ksiazka ksiazka = biblioteka.ZnajdzKsiazkePoId(idKsiazkiZ);
            string komunikat = biblioteka.Zwrot(ksiazka, peselUzytkownikaZ);

            MessageBox.Show(komunikat, "Zqracanie książki", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }
    }
}
