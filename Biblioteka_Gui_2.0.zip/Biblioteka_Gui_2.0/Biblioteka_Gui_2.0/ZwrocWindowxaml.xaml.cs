﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Biblioteka_projekt_2._0;

namespace Biblioteka_Gui_2._0
{
    /// <summary>
    /// Logika interakcji dla klasy ZwrocWindowxaml.xaml
    /// </summary>
    public partial class ZwrocWindowxaml : Window
    {
        private Biblioteka biblioteka;
        public ZwrocWindowxaml(Biblioteka biblioteka)
        {
            InitializeComponent();
            this.biblioteka = biblioteka;
            btnZwroc.Click += BtnZwroc_Click;
            btnAnuluj.Click += btnAnuluj_Click;
        }

     
        private void BtnZwroc_Click(object sender, RoutedEventArgs e)
        {

            string idKsiazkiZ = IDzwrotu.Text;
            string peselUzytkownikaZ = PeselZwrotu.Text;

            Ksiazka ksiazka = biblioteka.ZnajdzKsiazkePoId(idKsiazkiZ);
            Uzytkownik uzytkownik = biblioteka.SzukajPesel(peselUzytkownikaZ);

            

            if (ksiazka != null && uzytkownik != null)
            {

                MessageBoxResult re = MessageBox.Show($"Czy na pewno chcesz zwrócic ksiazke {idKsiazkiZ}?",
                                                  "Potwierdzenie zwrotu",
                                                  MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (re == MessageBoxResult.Yes)
                {
                    string komunikat = biblioteka.Zwrot(ksiazka, peselUzytkownikaZ);

                    MessageBox.Show($"Książka {idKsiazkiZ} została zwrócona ");
                    this.Close();
                }
                else
                {
                    MessageBox.Show($"Nie dokonano zwrotu");
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show($"Podany użytkownik bądź książka nie istnieją w systemie.");
            }

            

        }

        private void btnAnuluj_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
