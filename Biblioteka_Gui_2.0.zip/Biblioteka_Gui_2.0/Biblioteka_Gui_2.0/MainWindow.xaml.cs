﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Biblioteka_projekt_2._0;


namespace Biblioteka_Gui_2._0
{
    
    public partial class MainWindow : Window
    {
        Biblioteka biblioteka;
        List<Ksiazka> gotoweKsiazki;
        List<Uzytkownik> uzytkownicyList;
        public MainWindow()
        {
            InitializeComponent();
            Title = $"Biblioteka";
            biblioteka = new Biblioteka("Nasza biblioteka");

            biblioteka.OdczytajZPlikuXml("biblioteka.xml");
            Dodaj();
            BtnSzukajKsiazki.Click += BtnSzukajKsiazki_Click;
            BtnDodajUzytkownika.Click += BtnDodajUzytkownika_Click;
            BtnSzukajUzytkownicy.Click += BtnSzukajUzytkownicy_Click;
            BtnWypozycz.Click += BtnWypozycz_Click;
            BtnZwroc.Click += BtnZwroc_Click;
            BtnUsunUzytkownika.Click += BtnUsunUzytkownika_Click;
        }

        private void Dodaj()
        {
            gotoweKsiazki = biblioteka.WyswietlKsiazki();

            Autor AnnaPrzykladowa = new Autor("Anna", "Przykładowa");
            Autor JanKowalski = new Autor("Jan", "Kowalski");

            // Generowanie książek dla Anny Przykładowej
            Ksiazka ksiazka1 = new Ksiazka("Tytuł1", AnnaPrzykladowa, EnumWydawnictwo.Znak);
            Ksiazka ksiazka2 = new Ksiazka("Tytuł2", AnnaPrzykladowa, EnumWydawnictwo.Literackie);
            ksiazka1.DodajKategorie(EnumKategoria.naukowa);
            ksiazka2.DodajKategorie(EnumKategoria.biografia);

            // Generowanie książek dla Jana Kowalskiego
            Ksiazka ksiazka3 = new Ksiazka("Tytuł3", JanKowalski, EnumWydawnictwo.PWN);
            Ksiazka ksiazka4 = new Ksiazka("Tytuł4", JanKowalski, EnumWydawnictwo.Czarne);
            ksiazka3.DodajKategorie(EnumKategoria.romans);
            ksiazka3.DodajKategorie(EnumKategoria.fantastyka);
            ksiazka4.DodajKategorie(EnumKategoria.kryminał);

            biblioteka.DodajKsiazke(ksiazka1);
            biblioteka.DodajKsiazke(ksiazka2);
            biblioteka.DodajKsiazke(ksiazka3);
            biblioteka.DodajKsiazke(ksiazka4);
            


            Uzytkownik u1 = new Uzytkownik("Anna", "Kowalska", "12345678901", "123456789");
            Uzytkownik u2 = new Uzytkownik("Jan", "Nowak", "98765432109", "987654321");
            Uzytkownik u3 = new Uzytkownik("Alicja", "Nowacka", "11112222333", "111222333");
            Uzytkownik u4 = new Uzytkownik("Piotr", "Wiśniewski", "44445555666", "444555666");
            biblioteka.DodajUzytkownikaDoSystemu(u1);
            biblioteka.DodajUzytkownikaDoSystemu(u2);
            biblioteka.DodajUzytkownikaDoSystemu(u3);
            biblioteka.DodajUzytkownikaDoSystemu(u4);

            uzytkownicyList = biblioteka.WyswietlUzytkownikow();
        }
        private void BtnZwroc_Click(object sender, RoutedEventArgs e)
        {
            ZwrocWindowxaml zwrot = new ZwrocWindowxaml(biblioteka);
            zwrot.Show();
        }

        private void BtnWypozycz_Click(object sender, RoutedEventArgs e)
        {
            WypozyczWindow wypozycz = new WypozyczWindow(biblioteka);
            wypozycz.Show();
        }

        private void BtnSzukajKsiazki_Click(object sender, RoutedEventArgs e)
        {
           
            SzukajKsiazkaWindow szukajKsiazkaWindow = new SzukajKsiazkaWindow(biblioteka, gotoweKsiazki);
            szukajKsiazkaWindow.Show();
        }

        private void BtnUsunUzytkownika_Click(object sender, RoutedEventArgs e)
        {
            UsunUzytkownikaWindow form = new UsunUzytkownikaWindow(biblioteka);
            form.Show();
        }

        private void BtnSzukajUzytkownicy_Click(object sender, RoutedEventArgs e)
        {
            SzukajUzytkownikWindow form = new SzukajUzytkownikWindow(biblioteka, uzytkownicyList);
            form.Show();
        }

        private void BtnDodajUzytkownika_Click(object sender, RoutedEventArgs e)
        {
            DodajUzytkownikaWindow form = new DodajUzytkownikaWindow(biblioteka);
            form.Show();
        }
    }

  
}
