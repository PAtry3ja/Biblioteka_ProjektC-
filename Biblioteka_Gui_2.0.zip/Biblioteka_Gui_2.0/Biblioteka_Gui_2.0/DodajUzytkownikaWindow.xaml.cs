﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Biblioteka_projekt_2._0;

namespace Biblioteka_Gui_2._0
{
    /// <summary>
    /// Logika interakcji dla klasy DodajUzytkownikaWindow.xaml
    /// </summary>
    public partial class DodajUzytkownikaWindow : Window
    {
        private Biblioteka biblioteka;
        public DodajUzytkownikaWindow(Biblioteka biblioteka)
        {
            InitializeComponent();
            this.biblioteka = biblioteka;
            BtnZatwierdzDodanie.Click += BtnZatwierdzDodanie_Click;
        }

        private void BtnZatwierdzDodanie_Click(object sender, RoutedEventArgs e)
        {
            string imie = txtImie.Text;
            string nazwisko = txtNazwisko.Text;
            string pesel = txtPesel.Text;
            string numerTelefonu = txtNrTelefonu.Text;

            if (biblioteka.Uzytkownicy.Any(u => u.Pesel.CompareTo(pesel) == 0))
            {
                MessageBox.Show("Użytkownik o podanym PESEL już istnieje.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                Uzytkownik nowyUzytkownik = new Uzytkownik(imie, nazwisko, pesel, numerTelefonu);

                biblioteka.DodajUzytkownikaDoSystemu(nowyUzytkownik);

                this.Close();
            }
            catch (NiepoprawneDaneOsoboweException ex)
            {
                MessageBox.Show(ex.Message, "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}

