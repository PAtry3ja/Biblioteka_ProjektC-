﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Biblioteka_projekt_2._0;

namespace Biblioteka_Gui_2._0
{
    /// <summary>
    /// Logika interakcji dla klasy SzukajKsiazkaWindow.xaml
    /// </summary>
    public partial class SzukajKsiazkaWindow : Window
    {
        private Biblioteka biblioteka;
        public SzukajKsiazkaWindow(Biblioteka biblioteka, List<Ksiazka> dostepneKsiazki)
        {

            InitializeComponent();
            this.biblioteka = biblioteka;
            LstKsiazki.ItemsSource = dostepneKsiazki;

            BtnPokazDostepne.Click += BtnPokazDostepne_Click;
            BtnSzukajPoTytule.Click += BtnSzukajPoTytule_Click;
            BtnSzukajPoID.Click += BtnSzukajPoID_Click;
            BtnAnuluj.Click += BtnAnuluj_Click;

        }

        private void BtnPokazDostepne_Click(object sender, RoutedEventArgs e)
        {
            List<Ksiazka> znalezioneKsiazki = biblioteka.PobierzDostepne();
            LstKsiazki.ItemsSource = znalezioneKsiazki;
        }
        private void BtnSzukajPoTytule_Click(object sender, RoutedEventArgs e)
        {
            string tytul = Podanytytul.Text;
            
            List<Ksiazka> znalezioneKsiazki = biblioteka.PobierzPoTytule(tytul);
            LstKsiazki.ItemsSource = znalezioneKsiazki;

        }
        private void BtnSzukajPoID_Click(object sender, RoutedEventArgs e)
        {
            string szukaneId = PodaneID.Text;

            Ksiazka znalezionaKsiazka = biblioteka.ZnajdzKsiazkePoId(szukaneId);

            if (znalezionaKsiazka != null)
            {
                List<Ksiazka> listaKsiazek = new List<Ksiazka> { znalezionaKsiazka };

                
                LstKsiazki.ItemsSource = listaKsiazek;
            }
            else
            {
               
                LstKsiazki.ItemsSource = null;
            }
        }

        private void PodaneID_GotFocus(object sender, RoutedEventArgs e)
        {
            if (PodaneID.Text == "ID książki np.: 0001")
            {
                PodaneID.Text = string.Empty;
            }
        }

        private void Podanytytul_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Podanytytul.Text == "Tytuł książki")
            {
                Podanytytul.Text = string.Empty;
            }
        }

        private void BtnAnuluj_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
