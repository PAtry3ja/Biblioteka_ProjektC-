﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Biblioteka_projekt_2._0;

namespace Biblioteka_Gui_2._0
{
  
    public partial class UsunUzytkownikaWindow : Window
    {
        private Biblioteka biblioteka;
        public UsunUzytkownikaWindow(Biblioteka biblioteka)
        {
            InitializeComponent();
            this.biblioteka = biblioteka;
            BtnUsun.Click += BtnUsun_Click;
        }

        private void BtnUsun_Click(object sender, RoutedEventArgs e)
        {
           
            string PeselDoUsuniecia = txtPesel.Text;
            try
            {
                biblioteka.UsunUzytkownika(PeselDoUsuniecia);
                this.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
