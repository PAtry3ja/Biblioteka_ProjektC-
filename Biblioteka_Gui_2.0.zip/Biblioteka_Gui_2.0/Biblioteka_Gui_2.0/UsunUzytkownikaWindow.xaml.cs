﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Biblioteka_projekt_2._0;

namespace Biblioteka_Gui_2._0
{
  
   public partial class UsunUzytkownikaWindow : Window
{
    private Biblioteka biblioteka;

   public UsunUzytkownikaWindow(Biblioteka biblioteka)
   {
            InitializeComponent();
            this.biblioteka = biblioteka;
            BtnAnuluj.Click += BtnAnuluj_Click;

   }

    private void BtnUsun_Click(object sender, RoutedEventArgs e)
    {
        string peselDoUsuniecia = txtPesel.Text;

        MessageBoxResult result = MessageBox.Show($"Czy na pewno chcesz usunąć użytkownika o PESEL {peselDoUsuniecia}?",
                                                  "Potwierdzenie usunięcia",
                                                  MessageBoxButton.YesNo,
                                                  MessageBoxImage.Question);

        if (result == MessageBoxResult.Yes)
        {
            try
            {
                biblioteka.UsunUzytkownika(peselDoUsuniecia);
                MessageBox.Show($"Usunięto użytkownika o PESEL {peselDoUsuniecia}.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Wystąpił błąd podczas usuwania użytkownika: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        else if (result == MessageBoxResult.No)
        {
            MessageBox.Show("Nie usunięto użytkownika.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
            this.Close();
        }
    }

        private void BtnAnuluj_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }

}
