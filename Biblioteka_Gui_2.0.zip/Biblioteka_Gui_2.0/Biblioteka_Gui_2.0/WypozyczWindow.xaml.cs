﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Biblioteka_projekt_2._0;

namespace Biblioteka_Gui_2._0
{
    /// <summary>
    /// Logika interakcji dla klasy WypozyczWindow.xaml
    /// </summary>

        public partial class WypozyczWindow : Window
        {
            private Biblioteka biblioteka;
        
            public WypozyczWindow(Biblioteka biblioteka, List<Ksiazka> dostepneKsiazki)
            {

                InitializeComponent();
                this.biblioteka = biblioteka;
                LstKsiazki.ItemsSource = dostepneKsiazki;


                BtnWypzycz.Click += BtnWypozycz_Click;
                btnAnuluj.Click += btnAnuluj_Click;
            }

        private void BtnWypozycz_Click(object sender, RoutedEventArgs e)
        {
            string peselUzytkownika = PodanyPesel.Text;
            Uzytkownik uzytkownik = biblioteka.SzukajPesel(peselUzytkownika);
            if (uzytkownik!= null)
            {
                Ksiazka wybranaKsiazka = (Ksiazka)LstKsiazki.SelectedItem;
                
                string komunikat = biblioteka.Wypozyczenie(wybranaKsiazka, peselUzytkownika);
                MessageBox.Show(komunikat, "Wypożyczanie książki", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            else { MessageBox.Show("Wybrany uzytkownik nie istnieje"); }
        }

        private void btnAnuluj_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

    }
}

