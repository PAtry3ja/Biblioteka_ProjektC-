﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Biblioteka_projekt_2._0;

namespace Biblioteka_Gui_2._0
{
    /// <summary>
    /// Logika interakcji dla klasy WypozyczWindow.xaml
    /// </summary>
    public partial class WypozyczWindow : Window
    {
        private Biblioteka biblioteka;
        public WypozyczWindow(Biblioteka biblioteka)
        {
            InitializeComponent();
            this.biblioteka = biblioteka;
            BtnWypzycz.Click += BtnWypozycz_Click;
        }

        private void BtnWypozycz_Click(object sender, RoutedEventArgs e)
        {

            string idKsiazki = IDksiazki.Text;
            string peselUzytkownika = PodanyPesel.Text;

            Ksiazka ksiazka = biblioteka.ZnajdzKsiazkePoId(idKsiazki);
            string komunikat = biblioteka.Wypozyczenie(ksiazka, peselUzytkownika);

            MessageBox.Show(komunikat, "Wypożyczanie książki", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
