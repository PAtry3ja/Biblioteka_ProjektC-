﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Biblioteka_projekt_2._0;

namespace Biblioteka_Gui_2._0
{
    /// <summary>
    /// Logika interakcji dla klasy SzukajUzytkownikWindow.xaml
    /// </summary>
    public partial class SzukajUzytkownikWindow : Window
    {
        private Biblioteka biblioteka;
        private List<Uzytkownik> uzytkownicyList;

        public SzukajUzytkownikWindow(Biblioteka biblioteka, List<Uzytkownik> uzytkownicyList)
        {
            InitializeComponent();
            this.biblioteka = biblioteka;
            this.uzytkownicyList = uzytkownicyList;
            LstBoxUzytkownicy.ItemsSource = uzytkownicyList;

            BtnPokazWszystkich.Click += BtnPokazWszystkich_Click;
            BtnWyszukajWypozyczone.Click += BtnWyszukajWypozyczone_Click;
            BtnSzukajPesel.Click += BtnSzukajPesel_Click;

            BtnAnuluj.Click +=BtnAnuluj_Click;
        }       

        private void BtnPokazWszystkich_Click(object sender, RoutedEventArgs e)
        {
            LstBoxUzytkownicy.ItemsSource = biblioteka.WyswietlUzytkownikow();
        }

        private void BtnWyszukajWypozyczone_Click(object sender, RoutedEventArgs e)
        {
            string pesel = txtPeselWypozyczone.Text;

            if (string.IsNullOrEmpty(pesel) || pesel.Length != 11)
            {
                MessageBox.Show("Wprowadź poprawny numer PESEL.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            Uzytkownik foundUser = biblioteka.SzukajPesel(pesel);

            if (foundUser != null)
            {               
                List<Ksiazka> wypozyczoneKsiazki = biblioteka.WyświetlWypozyczoneKsiazki(foundUser);

                if (wypozyczoneKsiazki.Any())
                {
                    LstBoxUzytkownicy.ItemsSource = wypozyczoneKsiazki;
                    //MessageBox.Show($"Wypożyczone książki przez użytkownika {foundUser.Imie} {foundUser.Nazwisko}:\n{string.Join("\n", wypozyczoneKsiazki)}", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Użytkownik nie ma wypożyczonych książek.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Nie znaleziono użytkownika o podanym numerze PESEL.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnSzukajPesel_Click(object sender, RoutedEventArgs e)
        {
            string peselToSearch = txtPesel.Text;

            if (string.IsNullOrEmpty(peselToSearch) || peselToSearch.Length != 11)
            {
                MessageBox.Show("Wprowadź poprawny numer PESEL.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            Uzytkownik foundUser = biblioteka.SzukajPesel(peselToSearch);

            if (foundUser != null)
            {
                // Display information about the found user, or perform any other actions.
                MessageBox.Show($"Znaleziono użytkownika:\nImię: {foundUser.Imie}\nNazwisko: {foundUser.Nazwisko}", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Nie znaleziono użytkownika o podanym numerze PESEL.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnSortujAlfabetycznie_Click(object sender, RoutedEventArgs e)
        {                        
            LstBoxUzytkownicy.ItemsSource = biblioteka.SortujUzytnowkiów();
        }

        private void txtPesel_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtPesel.Text == "PESEL np.12345678910")
            {
                txtPesel.Text = string.Empty;
            }
        }

        private void txtPeselWypozyczone_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtPeselWypozyczone.Text == "PESEL np.12345678910")
            {
                txtPeselWypozyczone.Text = string.Empty;
            }
        }

        private void BtnAnuluj_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
